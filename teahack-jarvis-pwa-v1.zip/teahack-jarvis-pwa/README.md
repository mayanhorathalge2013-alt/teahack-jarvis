# TeaHack JARVIS PWA v1.0

A mobile-first, installable progressive web app starter. It is intentionally a local command interface, not yet a generative-AI chatbot.

## Included features
- Responsive dark sci-fi interface
- Live local clock and date
- Text commands: `help`, `time`, `date`, `search [topic]`, `open YouTube`, `open ChatGPT`, `save note [text]`, `show notes`, `clear notes`
- Browser search and quick-access shortcuts
- Local notes stored in browser `localStorage`
- Spoken responses where Web Speech synthesis is supported
- Speech recognition where browser support and permission are available
- Service worker cache for offline app-shell use after the first successful load
- PWA manifest and SVG icon

## Important limitations
- No AI model is connected in this version.
- Browser speech recognition is not available in every browser/device and may require an internet connection.
- The app must be served over HTTPS (or localhost for development) for service workers and normal PWA installation.
- Notes are local to this browser profile and can be lost if browser data is cleared. They are not encrypted, synced, or backed up.
- Do not put a private OpenAI API key in client-side JavaScript. A secure AI integration should use a small backend that keeps secrets off the phone's public app code.
- It does not have an always-listening wake word or unrestricted control over Android apps.

## Test locally
From a computer with Python installed, in this folder run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` in a browser. On Android, use a static HTTPS host to test and install it from Chrome's menu (wording varies by version).

## Publish from an Android phone
1. Extract the ZIP to a folder using a file manager.
2. Upload the folder's files to a static hosting service that supports HTTPS and serves `index.html` at the site root.
3. Open the HTTPS site in Chrome.
4. Use Chrome's menu and choose **Install app** or **Add to Home screen** if offered.
5. Test the commands, note saving, and voice controls. Speech features vary by browser.

## Security
This is a client-only app. Avoid storing sensitive information in notes. Before adding AI APIs, create a backend proxy with authentication, rate limits, and server-side secret storage.
