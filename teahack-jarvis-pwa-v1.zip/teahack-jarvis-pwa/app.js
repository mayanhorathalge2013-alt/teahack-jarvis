'use strict';
const $ = (selector) => document.querySelector(selector);
const response = $('#response');
const input = $('#commandInput');
let speechEnabled = true;
let recognition = null;

function updateClock(){
  const now = new Date();
  $('#clock').textContent = now.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});
  $('#dateText').textContent = now.toLocaleDateString([], {weekday:'short',year:'numeric',month:'short',day:'numeric'});
}
updateClock(); setInterval(updateClock, 1000);

function speak(text){
  if(!speechEnabled || !('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1; utterance.pitch = 1;
  window.speechSynthesis.speak(utterance);
}
function reply(text, shouldSpeak=true){
  response.querySelector('p').textContent = text;
  if(shouldSpeak) speak(text);
}
function openSearch(query){
  const url = 'https://www.google.com/search?q=' + encodeURIComponent(query);
  window.open(url, '_blank', 'noopener,noreferrer');
  reply('Opening a web search for: ' + query);
}
function runCommand(raw){
  const command = raw.trim();
  if(!command){ reply('Please type a command first.', false); return; }
  const lower = command.toLowerCase();
  if(['help','commands','what can you do','aide','/help'].includes(lower)){
    reply('Available commands: “time” or “date”; “search [topic]”; “open YouTube”; “open ChatGPT”; “save note [text]”; “show notes”; and “clear notes”. Use the tool cards for shortcuts.');
  } else if(['time','what time is it','heure','date','what is the date','quelle date'].includes(lower)){
    const now = new Date();
    reply('It is ' + now.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'}) + ' on ' + now.toLocaleDateString([], {weekday:'long',year:'numeric',month:'long',day:'numeric'}) + '.');
  } else if(lower.startsWith('search ')){
    const query = command.slice(7).trim();
    if(query) openSearch(query); else reply('Tell me what you want to search for.', false);
  } else if(lower === 'open youtube' || lower === 'youtube'){
    window.open('https://www.youtube.com/', '_blank', 'noopener,noreferrer'); reply('Opening YouTube.');
  } else if(lower === 'open chatgpt' || lower === 'chatgpt'){
    window.open('https://chatgpt.com/', '_blank', 'noopener,noreferrer'); reply('Opening ChatGPT.');
  } else if(lower.startsWith('save note ')){
    const note = command.slice(10).trim();
    if(note){ addNote(note); reply('Saved your note on this device.'); } else reply('Please add the note text after “save note”.', false);
  } else if(lower === 'show notes'){
    const notes = getNotes(); reply(notes.length ? 'You have ' + notes.length + ' saved note' + (notes.length===1?'':'s') + '. They are listed in the Quick notes section.' : 'You do not have any saved notes yet.');
  } else if(lower === 'clear notes'){
    if(window.confirm('Delete all notes saved in this browser?')){ localStorage.removeItem('teahack-notes-v1'); renderNotes(); reply('All local notes have been cleared.'); }
    else reply('Cancelled. Your notes were kept.', false);
  } else if(lower === 'hello' || lower === 'hi' || lower === 'hey'){
    reply('Hello. TeaHack JARVIS is ready. What would you like to do?');
  } else {
    reply('I can run simple commands, but this version is not connected to an AI model yet. Try “help”, or use “search ' + command.slice(0,80) + '” to look it up online.');
  }
}
$('#commandForm').addEventListener('submit', (event)=>{event.preventDefault();runCommand(input.value);input.value='';input.focus();});
document.querySelectorAll('[data-command]').forEach(button=>button.addEventListener('click',()=>runCommand(button.dataset.command)));
document.querySelectorAll('[data-url]').forEach(button=>button.addEventListener('click',()=>{window.open(button.dataset.url,'_blank','noopener,noreferrer');reply('Opening ' + button.querySelector('strong').textContent + '.');}));

function getNotes(){try{const value=JSON.parse(localStorage.getItem('teahack-notes-v1')||'[]');return Array.isArray(value)?value:[]}catch{return []}}
function addNote(text){const notes=getNotes();notes.unshift({id:Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7),text,created:new Date().toISOString()});try{localStorage.setItem('teahack-notes-v1',JSON.stringify(notes.slice(0,100)));renderNotes();}catch{reply('Could not save the note. Your browser storage may be full or disabled.',false)}}
function renderNotes(){const list=$('#notesList');list.replaceChildren();const notes=getNotes();if(!notes.length){const li=document.createElement('li');li.className='empty-note';li.textContent='No notes yet. Add an idea above.';list.append(li);return;}for(const note of notes){const li=document.createElement('li');const span=document.createElement('span');span.className='note-text';span.textContent=note.text;const del=document.createElement('button');del.className='delete-note';del.type='button';del.textContent='×';del.setAttribute('aria-label','Delete note');del.addEventListener('click',()=>{const next=getNotes().filter(item=>item.id!==note.id);localStorage.setItem('teahack-notes-v1',JSON.stringify(next));renderNotes();});li.append(span,del);list.append(li);}}
$('#noteForm').addEventListener('submit',(event)=>{event.preventDefault();const note=$('#noteInput').value.trim();if(!note)return;addNote(note);$('#noteInput').value='';reply('Note saved.');});renderNotes();

$('#speakToggle').addEventListener('click',()=>{speechEnabled=!speechEnabled;const button=$('#speakToggle');button.classList.toggle('active',speechEnabled);button.setAttribute('aria-pressed',String(speechEnabled));button.querySelector('span').textContent=speechEnabled?'Speech on':'Speech off';if(!speechEnabled&&'speechSynthesis'in window)window.speechSynthesis.cancel();reply(speechEnabled?'Spoken responses are enabled where supported.':'Spoken responses are disabled.',false);});
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const micBtn=$('#micBtn');
if(SpeechRecognition){recognition=new SpeechRecognition();recognition.lang=navigator.language||'en-US';recognition.interimResults=false;recognition.maxAlternatives=1;recognition.onstart=()=>{$('#voiceStatus').textContent='Listening… speak now.';micBtn.classList.add('active');};recognition.onresult=(event)=>{const transcript=event.results[0][0].transcript;input.value=transcript;runCommand(transcript);input.value='';};recognition.onerror=(event)=>{$('#voiceStatus').textContent='Voice input issue: '+event.error+'. You can type commands instead.';};recognition.onend=()=>{micBtn.classList.remove('active');if(!$('#voiceStatus').textContent.startsWith('Voice input issue'))$('#voiceStatus').textContent='Voice recognition ready.';};micBtn.addEventListener('click',()=>{try{recognition.start();}catch{$('#voiceStatus').textContent='Already listening. Try again in a moment.';}});$('#voiceStatus').textContent='Voice recognition available in this browser.';}else{micBtn.addEventListener('click',()=>reply('This browser does not provide speech recognition here. You can still type commands.',false));$('#voiceStatus').textContent='Voice recognition is not supported here; typing still works.';}

if('serviceWorker' in navigator && location.protocol.startsWith('http')){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
